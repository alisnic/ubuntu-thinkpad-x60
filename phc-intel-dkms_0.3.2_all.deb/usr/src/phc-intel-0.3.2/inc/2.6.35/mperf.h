/*
 *  (c) 2010 Advanced Micro Devices, Inc.
 *  Your use of this code is subject to the terms and conditions of the
 *  GNU general public license version 2. See "COPYING" or
 *  http://www.gnu.org/licenses/gpl.html
 */

unsigned int cpufreq_get_measured_perf(struct cpufreq_policy *policy,
					unsigned int cpu);
